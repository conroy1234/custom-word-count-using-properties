package my.inmemory.cash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CashingApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(CashingApplication.class, args);
	}

}
